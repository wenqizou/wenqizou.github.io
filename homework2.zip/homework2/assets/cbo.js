$(document).ready(function () {
  new cursoreffects.emojiCursor({
    emoji: [
      // '\u2764\uFE0F',
      // '\uD83D\uDC98',
      // '\uD83D\uDC95',
      // '\uD83D\uDC9B',
      // '\uD83C\uDF54',
      // '\uD83D\uDC96',
      // '\uD83E\uDD64',
      // '\uD83D\uDC9D',
      // '\uD83D\uDC98',
      // '\uD83D\uDC97'
      '🥯',
      '🥩',
      '🍗',
      '🧀',
      '🍕',
      '🥗',
      '🌮',
      '🌭',
      '🍤',
      '🍥',
      '🍭',
      '🍫',
      '🧁',
      '🍪',
      '🍿',
      '🧃',
      '🍬',
      '🥟'
    ]
  })
  // setTimeout(function () {
  //   $('.cc-banner').is('.cc-invisible') ||
  //     $('.accessibly-otm-widget-button-container').addClass(
  //       'accessibly-otm-widget-button-container-open'
  //     ),
  //     $('.cc-banner').on('click', function () {
  //       console.log('test')
  //     })
  // }, 1e3)
})
//# sourceMappingURL=/s/files/1/0708/7272/7835/t/2/assets/cbo.js.map?v=133581524199139336391676425839
